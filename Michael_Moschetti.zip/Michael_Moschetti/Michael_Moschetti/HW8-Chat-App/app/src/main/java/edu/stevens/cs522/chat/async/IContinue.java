package edu.stevens.cs522.chat.async;

/**
 * Created by dduggan.
 */

public interface IContinue<T> {
    public void kontinue(T value);
}

